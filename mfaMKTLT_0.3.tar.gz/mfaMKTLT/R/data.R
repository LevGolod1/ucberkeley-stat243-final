#' Results of a (fictitious) wine-tasting experiment.
#'
#' The data concern 12 wines from different regions. 10 wine critics were each
#'   asked to evaluate all 12 wines. The critics used a variety of criteria.
#'   Each of the critics used V1 - V4. Each critic was also free to choose up
#'   to two additional criteria from V5 - V15.
#'
#' @format A data frame with 12 rows (wines) and 53 variables (assessor
#'   criteria):
#' \describe{
#'   \item{V1}{cat pee}
#'   \item{V2}{passion fruit}
#'   \item{V3}{green pepper}
#'   \item{V4}{mineral}
#'   \item{V5}{smoky}
#'   \item{V6}{citrus}
#'   \item{V7}{tropical}
#'   \item{V8}{leafy}
#'   \item{V9}{grassy}
#'   \item{V10}{flinty}
#'   \item{V11}{vegetal}
#'   \item{V12}{hay}
#'   \item{V13}{melon}
#'   \item{V14}{grass}
#'   \item{V15}{peach}
#'   \item{acidity}{titratable acidity}
#'   \item{ph}{pH}
#'   \item{alcohol}{alcohol }
#'   \item{res_sugar}{residual sugar}
#' }
#' @source Professor Gaston Sanchez, Stat 243, UC Berkeley, Fall 2016
"winedata"
